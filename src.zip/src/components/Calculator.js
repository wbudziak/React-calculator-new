/* eslint-disable default-case */
import React, { useEffect, useState } from "react";
import Inputs from "./Inputs";
import Keyboard from "./Keyboard";
import styles from "./Calculator.module.css";

const Calculator = (props) => {
  const [prevValue, setPrevValue] = useState("");
  const [nextValue, setNextValue] = useState("");
  const [currentResult, setCurrentResult] = useState("");
  const [firstNumber, setFirstNumber] = useState(true);
  const [Operator, setOperator] = useState("");
  const [operatorEnable, setOperatorEnable] = useState(true);
  const [displayOperator, setDisplayOperator] = useState("");
  const [equalIsClicked, setEqualIsClicked] = useState(false);
  const [finalResult, setFinalResult] = useState("");
  const [displayCurrent, setDisplayCurrent] = useState("");
  const [displayPreview, setDisplayPreview] = useState("");
  const [saveFirstValue, setSaveFirstValue] = useState("");
  const [saveFirstValueFlag, setSaveFirsValueFlag] = useState(false);

  useEffect(() => {
    setDisplayPreview(firstNumber === true ? "" : prevValue + displayOperator);
    setDisplayCurrent(firstNumber === true ? prevValue : nextValue);
    setSaveFirstValue(saveFirstValueFlag === false ? prevValue : nextValue);
    switch (Operator) {
      case "*":
        setCurrentResult(parseFloat(prevValue) * parseFloat(nextValue));
        setDisplayOperator(" x");
        break;
      case "+":
        setCurrentResult(parseFloat(prevValue) + parseFloat(nextValue));
        setDisplayOperator(" +");
        break;
      case "-":
        setCurrentResult(parseFloat(prevValue) - parseFloat(nextValue));
        setDisplayOperator(" -");
        break;
      case "/":
        setCurrentResult(parseFloat(prevValue) / parseFloat(nextValue));
        setDisplayOperator(" ÷");
        break;
      case "%":
        setCurrentResult(parseFloat(prevValue) % parseFloat(nextValue));
        setDisplayOperator(" %");
        break;
    }
  }, [prevValue, nextValue, currentResult, Operator, displayOperator]);

  const resetHandler = (e) => {
    setPrevValue("");
    // setPrevValue(equalIsClicked === true ? e.target.value : "");

    setNextValue("");
    setCurrentResult("");
    setFirstNumber(true);
    setOperator("");
    setOperatorEnable(true);
    setDisplayOperator("");
    setFinalResult("");
    setEqualIsClicked(false);
    setSaveFirstValue("");
    setSaveFirsValueFlag(false);
  };
  const switchValueHandler = (e) => {
    if (firstNumber) {
      if (prevValue.toString().includes("-")) {
        setPrevValue(prevValue.slice(1));
      } else {
        if (prevValue.toString().length <= 0) return;
        setPrevValue("-" + prevValue);
      }
    } else if (!firstNumber) {
      if (nextValue.toString().includes("-")) {
        setNextValue(nextValue.slice(1));
      } else {
        if (nextValue.toString().length <= 0) return;
        setNextValue("-" + nextValue);
      }
    }
  };
  const operatorHandler = (e) => {
    if (operatorEnable === false || prevValue === "") return;
    if (prevValue === "0.") return;
    setOperatorEnable(false);
    if (firstNumber) {
      if (equalIsClicked === true) {
        setNextValue("");
        setFinalResult("");
      }
      setFirstNumber(false);
      setOperator(e.target.value);
    } else {
      setPrevValue(currentResult);
      setNextValue("");
      setOperator(e.target.value);
    }
  };
  const numberHandler = (e) => {
    if (firstNumber) {
      if (equalIsClicked === true) {
        resetHandler(e);
      }
      if (e.target.value === "0" && equalIsClicked === true) {
        resetHandler(e);
        return;
      }
      if (e.target.value === "0" && prevValue === "") return;

      if (equalIsClicked === true) {
        setPrevValue(
          e.target.value === "." && prevValue !== ""
            ? "0" + e.target.value
            : e.target.value
        );
      } else {
        if (e.target.value === "." && prevValue.includes(".")) return;
        setPrevValue(
          e.target.value === "." && prevValue === ""
            ? prevValue + "0" + e.target.value
            : prevValue + e.target.value
        );
      }
    } else if (firstNumber === false) {
      if (e.target.value === "." && nextValue.includes(".")) return;
      if (e.target.value === "0" && nextValue === "") return;

      setOperatorEnable(true);
      setNextValue(
        e.target.value === "." && nextValue === ""
          ? nextValue + "0" + e.target.value
          : nextValue + e.target.value
      );
    }
  };
  const equalHandler = (e) => {
    setSaveFirsValueFlag(true);
    setFinalResult(currentResult);
    setFirstNumber(true);
    setEqualIsClicked(true);
    setPrevValue(currentResult);
    setNextValue(nextValue === "" ? "" : saveFirstValue);
  };
  const keyHandler = (e) => {
    switch (e.target.getAttribute("type")) {
      case "switch":
        switchValueHandler();
        break;
      case "number":
        numberHandler(e);
        break;
      case "reset": {
        resetHandler(e);
        break;
      }
      case "operator": {
        operatorHandler(e);
        break;
      }
      case "equal": {
        equalHandler(e);
        break;
      }
    }
  };
  return (
    <>
      <calculator className={styles.calculator}>
        <Inputs
          finalResult={finalResult}
          displayCurrent={displayCurrent}
          displayPreview={displayPreview}
        ></Inputs>
        <Keyboard click={keyHandler}></Keyboard>
      </calculator>
    </>
  );
};
export default Calculator;
