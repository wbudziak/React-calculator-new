import React, { useEffect, useState } from "react";
import styles from "./screen.module.css";

const Inputs = (props) => {
  const { displayCurrent, finalResult, displayPreview } = props;
  const [fontSize, setFontSize] = useState(32);

  return (
    <screen className={styles.screen}>
      <input
        className={styles.previousOperand}
        type="text"
        readOnly
        value={finalResult === "" ? displayPreview : ""}
      />
      <input
        style={{ fontSize: `${fontSize}px` }}
        className={styles.currentOperand}
        type="text"
        placeholder="0"
        readOnly
        value={finalResult === "" ? displayCurrent : finalResult}
      />
    </screen>
  );
};
export default Inputs;
