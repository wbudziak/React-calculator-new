import React, { useState } from "react";
import Calculator from "./components/Calculator";
function App() {
  return (
    <>
      <Calculator></Calculator>
    </>
  );
}

export default App;
