/* eslint-disable default-case */
import React, { useEffect, useState } from "react";
import Inputs from "./Inputs";
import Keyboard from "./Keyboard";
import styles from "./Calculator.module.css";

const Calculator = (props) => {
  const [current, setCurrent] = useState("");
  const [prev, setPrev] = useState("");
  const [currentResult, setCurrentResult] = useState("");
  const [operator, setOperator] = useState("");
  const [equalIsClicked, setEqualIsClicked] = useState(false);
  const [saveFirstValue, setSaveFirstValue] = useState("");
  const [saveFirstValueFlag, setSaveFirsValueFlag] = useState(false);
  const [finalResult, setFinalResult] = useState("");
  const switchValue = (e) => {};

  useEffect(() => {
    setSaveFirstValue(saveFirstValueFlag === false ? "" : current);
    if (equalIsClicked) {
      setFinalResult(currentResult);
    }
    if (current !== "" && prev !== "") {
      switch (operator) {
        case "*":
          setCurrentResult(parseFloat(current) * parseFloat(prev));
          break;
        case "+":
          setCurrentResult(parseFloat(prev) + parseFloat(current));
          break;
        case "-":
          setCurrentResult(parseFloat(prev) - parseFloat(current));
          break;
        case "/":
          setCurrentResult(parseFloat(prev) / parseFloat(current));
          break;
        case "%":
          setCurrentResult(parseFloat(prev) % parseFloat(current));
          break;
      }
    }
  }, [operator, prev, current, currentResult]);

  const reset = (e) => {
    setPrev("");
    setCurrent("");
    setCurrentResult("");
    setOperator("");
    setEqualIsClicked(false);
    setFinalResult("");
  };
  const equalHandler = (e) => {
    if (equalIsClicked) {
      setCurrent(current);
      setPrev(currentResult);
    }
    setEqualIsClicked(true);
    setFinalResult(currentResult);
  };
  const operatorHandler = (e) => {
    setFinalResult("");
    setEqualIsClicked(false);
    setOperator(e.target.value);
    if (current !== "") {
      setPrev(current);
      setCurrent("");
    }
    if (currentResult !== "") {
      setCurrent("");
      setPrev(currentResult);
    }
  };
  const enterNumber = (e) => {
    if (equalIsClicked && e.target.value === "0") {
      reset(e);
      return;
    }
    if (equalIsClicked) {
      reset(e);
      setCurrent(
        e.target.value === "." && current !== ""
          ? "0" + e.target.value
          : e.target.value
      );
      return;
    }
    if (e.target.value === "0" && current === "") return;
    if (e.target.value === "." && current.includes(".")) return;
    setCurrent(
      e.target.value === "." && current === ""
        ? current + "0" + e.target.value
        : current + e.target.value
    );
  };
  const buttonHandler = (e) => {
    if (e.target.getAttribute("type") === "number") {
      enterNumber(e);
    }
    if (e.target.getAttribute("type") === "operator") {
      operatorHandler(e);
    }
    if (e.target.getAttribute("type") === "equal") {
      equalHandler(e);
    }
    if (e.target.getAttribute("type") === "reset") {
      reset(e);
    }
  };
  return (
    <>
      <calculator className={styles.calculator}>
        <Inputs
          prev={prev}
          current={current}
          finalResult={finalResult}
        ></Inputs>
        <Keyboard click={buttonHandler}></Keyboard>
      </calculator>
    </>
  );
};
export default Calculator;
